package com.hydroproxy;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import java.nio.charset.StandardCharsets;

public class BackendHandler extends SimpleChannelInboundHandler<ByteBuf> {

    private final Channel clientChannel;

    public BackendHandler(Channel clientChannel) {
        this.clientChannel = clientChannel;
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        super.channelActive(ctx);
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, ByteBuf msg) {
        int packetId = readVarInt(msg.copy());

        // 0x17 = Plugin Message (Play state)
        if (packetId == 0x17) {
            String channel = readString(msg.copy());

            // minecraft:brand is the brand packet
            if (channel.equals("minecraft:brand")) {
                // DROP backend brand and send ours instead
                sendCustomBrand();
                return;
            }
        }

        // Forward everything else
        if (clientChannel.isActive()) {
            clientChannel.writeAndFlush(msg.retain());
        }
    }

    private void sendCustomBrand() {
        String brandString = "HydroProxy (1.4.x, 1.5.x, 1.6. 1.7.x 1.8.x 1.9.x 1.10.x 1.11.x 1.12.x 1.13.x 1.14.x 1.15.x 1.16.x 1.17.x 1.18.x 1.19.x 1.20.x 1.21.x 26.x)";

        ByteBuf brand = Unpooled.buffer();
        writeVarInt(brand, "minecraft:brand".length());
        brand.writeBytes("minecraft:brand".getBytes(StandardCharsets.UTF_8));

        byte[] brandData = brandString.getBytes(StandardCharsets.UTF_8);
        ByteBuf data = Unpooled.buffer();
        writeVarInt(data, brandData.length);
        data.writeBytes(brandData);

        ByteBuf packet = Unpooled.buffer();
        writeVarInt(packet, 0x17); // Plugin Message
        packet.writeBytes(brand);

        writeVarInt(packet, data.readableBytes());
        packet.writeBytes(data);

        clientChannel.writeAndFlush(packet);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        if (clientChannel.isActive()) {
            clientChannel.close();
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        ctx.close();
        if (clientChannel.isActive()) {
            clientChannel.close();
        }
    }

    // ---- Helpers ----

    private int readVarInt(ByteBuf buf) {
        int numRead = 0;
        int result = 0;
        byte read;
        do {
            read = buf.readByte();
            int value = (read & 0b01111111);
            result |= (value << (7 * numRead));

            numRead++;
            if (numRead > 5) return 0;
        } while ((read & 0b10000000) != 0);

        return result;
    }

    private String readString(ByteBuf buf) {
        int len = readVarInt(buf);
        byte[] bytes = new byte[len];
        buf.readBytes(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private void writeVarInt(ByteBuf buf, int value) {
        while ((value & 0xFFFFFF80) != 0L) {
            buf.writeByte((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        buf.writeByte(value & 0x7F);
    }
}

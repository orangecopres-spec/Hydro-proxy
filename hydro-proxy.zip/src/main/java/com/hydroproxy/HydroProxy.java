package com.hydroproxy;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;

public class HydroProxy {

    // Proxy listen port
    public static final int PROXY_PORT = 25567;

    // Backend server (your Paper/Purpur/etc)
    public static final String BACKEND_HOST = "127.0.0.1";
    public static final int BACKEND_PORT = 25566;

    public static void main(String[] args) throws InterruptedException {
        EventLoopGroup boss = new NioEventLoopGroup(1);
        EventLoopGroup worker = new NioEventLoopGroup();

        try {
            ServerBootstrap bootstrap = new ServerBootstrap();
            bootstrap.group(boss, worker)
                    .channel(NioServerSocketChannel.class)
                    .childHandler(new ProxyInitializer());

            ChannelFuture future = bootstrap.bind(PROXY_PORT).sync();
            System.out.println("HydroProxy listening on port " + PROXY_PORT);
            future.channel().closeFuture().sync();
        } finally {
            boss.shutdownGracefully();
            worker.shutdownGracefully();
        }
    }
}

package com.hydroproxy;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.nio.charset.StandardCharsets;

public class ClientHandler extends SimpleChannelInboundHandler<ByteBuf> {

    private Channel backendChannel;

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, ByteBuf in) throws Exception {
        // Mark reader index so we can re-use the buffer if needed
        in.markReaderIndex();

        if (backendChannel == null) {
            // First packet should be handshake
            int packetLength = readVarInt(in);
            if (packetLength == -1 || in.readableBytes() < packetLength) {
                in.resetReaderIndex();
                return;
            }

            int packetId = readVarInt(in);
            if (packetId != 0x00) {
                // Not a handshake, just close
                ctx.close();
                return;
            }

            int protocolVersion = readVarInt(in);
            String serverAddress = readString(in);
            int serverPort = in.readUnsignedShort();
            int nextState = readVarInt(in); // 1 = status, 2 = login

            if (nextState == 1) {
                // STATUS: respond with ping info and close
                handleStatus(ctx, protocolVersion);
            } else if (nextState == 2) {
                // LOGIN: connect to backend and forward everything (including this handshake)
                in.resetReaderIndex();
                connectBackendAndForward(ctx, in);
            } else {
                ctx.close();
            }
        } else {
            // Already connected to backend: just forward
            backendChannel.writeAndFlush(in.retain());
        }
    }

    private void handleStatus(ChannelHandlerContext ctx, int protocolVersion) {
        // Simple status response
        String json = """
                {
                  "version": { "name": "HydroProxy", "protocol": %d },
                  "players": { "max": 100, "online": 0 },
                  "description": { "text": "Hydro Proxy from scratch" }
                }
                """.formatted(protocolVersion);

        ByteBuf response = Unpooled.buffer();

        // Response packet: ID 0x00 (status response)
        ByteBuf jsonBytes = Unpooled.copiedBuffer(json, StandardCharsets.UTF_8);
        ByteBuf packet = Unpooled.buffer();
        writeVarInt(packet, 0x00); // packet id
        writeVarInt(packet, jsonBytes.readableBytes());
        packet.writeBytes(jsonBytes);

        writeVarInt(response, packet.readableBytes());
        response.writeBytes(packet);

        ctx.writeAndFlush(response).addListener(ChannelFutureListener.CLOSE);
    }

    private void connectBackendAndForward(ChannelHandlerContext clientCtx, ByteBuf firstPacket) {
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.group(clientCtx.channel().eventLoop())
                .channel(NioSocketChannel.class)
                .handler(new ChannelInitializer<Channel>() {
                    @Override
                    protected void initChannel(Channel ch) {
                        ch.pipeline().addLast(new BackendHandler(clientCtx.channel()));
                    }
                });

        bootstrap.connect(HydroProxy.BACKEND_HOST, HydroProxy.BACKEND_PORT)
                .addListener((ChannelFutureListener) future -> {
                    if (!future.isSuccess()) {
                        clientCtx.close();
                        return;
                    }
                    backendChannel = future.channel();
                    // Forward the first packet (handshake + login start)
                    backendChannel.writeAndFlush(firstPacket.retain());
                });
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        if (backendChannel != null && backendChannel.isActive()) {
            backendChannel.close();
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        ctx.close();
        if (backendChannel != null) {
            backendChannel.close();
        }
    }

    // ---- Minimal VarInt + String helpers ----

    private int readVarInt(ByteBuf buf) {
        int numRead = 0;
        int result = 0;
        byte read;
        do {
            if (!buf.isReadable()) return -1;
            read = buf.readByte();
            int value = (read & 0b01111111);
            result |= (value << (7 * numRead));

            numRead++;
            if (numRead > 5) {
                return -1;
            }
        } while ((read & 0b10000000) != 0);

        return result;
    }

    private String readString(ByteBuf buf) {
        int length = readVarInt(buf);
        byte[] bytes = new byte[length];
        buf.readBytes(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private void writeVarInt(ByteBuf buf, int value) {
        while ((value & 0xFFFFFF80) != 0L) {
            buf.writeByte((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        buf.writeByte(value & 0x7F);
    }
}
